import React, { useState, useEffect, useRef } from 'react'
import { auth } from './main'
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged, User, signOut } from 'firebase/auth'
import { Upload, FileSpreadsheet, AlertCircle, Download, UserPlus, LogIn } from 'lucide-react'
import * as XLSX from 'xlsx'
import { db } from './main'
import { doc, getDoc, setDoc, increment, Timestamp } from 'firebase/firestore'

const SCRIPTS = {
  run5: `
    function compareAndDisplayData(XLSX, file1, file2) {
      // Main HUB vs Sales comparison logic
      const workbook1 = XLSX.read(file1);
      const workbook2 = XLSX.read(file2);
      return [['Comparison Results'], ['Sample Data']];
    }
  `,
  test20: `
    function compareAndDisplayData(XLSX, file1, file2) {
      // Read workbooks
      const workbook1 = XLSX.read(file1);
      const workbook2 = XLSX.read(file2);
    
      // Get first sheet from each workbook
      const sheet1 = workbook1.Sheets[workbook1.SheetNames[0]];
      const sheet2 = workbook2.Sheets[workbook2.SheetNames[0]];
    
      // Convert sheets to JSON
      const data1 = XLSX.utils.sheet_to_json(sheet1);
      const data2 = XLSX.utils.sheet_to_json(sheet2);
    
      // Extract values from the specified columns
      const cardBrands = new Set(data1.map(row => row['Card Brand']?.toString().toLowerCase().trim()));
      const names = new Set(data2.map(row => row['Name']?.toString().toLowerCase().trim()));
    
      // Find matching items
      const matches = new Set();
      cardBrands.forEach(brand => {
        if (names.has(brand)) {
          matches.add(brand);
        }
      });
    
      // Prepare results
      const results = [
        ['Metric', 'Count'],
        ['Total Card Brands in File 1', cardBrands.size],
        ['Total Names in File 2', names.size],
        ['Number of Matching Items', matches.size]
      ];
    
      // Add matching items list
      results.push(['', '']);
      results.push(['Matching Items:', '']);
      [...matches].sort().forEach(match => {
        results.push([match, '']);
      });
    
      return results;
    }
  `
};

interface UserUsage {
  comparisons: number;
  lastReset: Timestamp;
  plan: 'basic' | 'premium';
}

const PLAN_LIMITS = {
  basic: 50,
  premium: 100
};

function App() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, 
      (user) => {
        setUser(user)
        setIsLoading(false)
        setError(null)
      },
      (error) => {
        console.error('Auth error:', error)
        setError('Authentication service is unavailable. Please check your connection.')
        setIsLoading(false)
      }
    )

    return () => unsubscribe()
  }, [])

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-red-50 p-4 rounded-lg border border-red-200">
          <p className="text-red-700">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-4 bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  if (!user) {
    return <LoginPage />
  }

  return <MainPage user={user} />
}

function LoginPage() {
  const [isRegistering, setIsRegistering] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    try {
      if (isRegistering) {
        if (password !== confirmPassword) {
          setError('Passwords do not match')
          return
        }
        if (password.length < 6) {
          setError('Password must be at least 6 characters long')
          return
        }
        await createUserWithEmailAndPassword(auth, email, password)
      } else {
        await signInWithEmailAndPassword(auth, email, password)
      }
    } catch (error: any) {
      if (error.code === 'auth/email-already-in-use') {
        setError('An account with this email already exists')
      } else if (error.code === 'auth/invalid-email') {
        setError('Invalid email address')
      } else if (error.code === 'auth/weak-password') {
        setError('Password is too weak')
      } else {
        setError('Invalid email or password')
      }
    }
  }

  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4 py-6">
      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg w-full max-w-md">
        <div className="flex flex-col items-center space-y-3 mb-6">
          <img src="https://github.com/davisricart/grbalance-auth/blob/main/public/images/gr-logo.png?raw=true" alt="GR Logo" className="h-24 sm:h-30 w-auto object-contain" />
          <p className="text-emerald-700 text-center text-base sm:text-lg font-medium">
            {isRegistering ? 'Create Account' : 'Sign In'}
          </p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-emerald-600 mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-emerald-100 focus:ring-2 focus:ring-emerald-400/50 focus:border-transparent transition duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-emerald-600 mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-emerald-100 focus:ring-2 focus:ring-emerald-400/50 focus:border-transparent transition duration-200"
              required
            />
          </div>

          {isRegistering && (
            <div>
              <label className="block text-sm font-medium text-emerald-600 mb-1.5">Confirm Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg border border-emerald-100 focus:ring-2 focus:ring-emerald-400/50 focus:border-transparent transition duration-200"
                required
              />
            </div>
          )}

          {error && (
            <div className="text-red-600 text-sm bg-red-50/50 p-3 rounded-md border border-red-100">{error}</div>
          )}

          <button
            type="submit"
            className="w-full bg-emerald-600 text-white py-2.5 px-4 rounded-lg hover:bg-emerald-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transform hover:scale-[1.02] transition-all duration-200 flex items-center justify-center gap-2"
          >
            {isRegistering ? <UserPlus className="w-4 h-4" /> : <LogIn className="w-4 h-4" />}
            {isRegistering ? 'Create Account' : 'Sign In'}
          </button>

          <p className="text-center text-sm text-gray-600 mt-4">
            {isRegistering ? 'Already have an account?' : "Don't have an account?"}
            <button
              type="button"
              onClick={() => {
                setIsRegistering(!isRegistering)
                setError('')
                setPassword('')
                setConfirmPassword('')
              }}
              className="ml-1 text-emerald-600 hover:text-emerald-700 font-medium"
            >
              {isRegistering ? 'Sign In' : 'Create Account'}
            </button>
          </p>
        </form>
      </div>
    </div>
  )
}

function MainPage({ user }: { user: User }) {
  const [file1, setFile1] = useState<File | null>(null)
  const [file2, setFile2] = useState<File | null>(null)
  const [script, setScript] = useState('')
  const [status, setStatus] = useState('')
  const [results, setResults] = useState<any[]>([])
  const [usageCount, setUsageCount] = useState(0)
  const [userPlan, setUserPlan] = useState<'basic' | 'premium'>('basic')
  const [isLimitReached, setIsLimitReached] = useState(false)
  const file1Ref = useRef<HTMLInputElement>(null)
  const file2Ref = useRef<HTMLInputElement>(null)

  useEffect(() => {
    checkUserUsage()
  }, [user.uid])

  const checkUserUsage = async () => {
    try {
      const userRef = doc(db, 'usage', user.uid)
      const subscriptionRef = doc(db, 'subscriptions', user.uid)
      
      const [userDoc, subscriptionDoc] = await Promise.all([
        getDoc(userRef),
        getDoc(subscriptionRef)
      ])
      
      const plan = subscriptionDoc.exists() ? subscriptionDoc.data().plan : 'basic'
      setUserPlan(plan)
      const monthlyLimit = PLAN_LIMITS[plan]

      if (!userDoc.exists()) {
        await setDoc(userRef, {
          comparisons: 0,
          lastReset: Timestamp.now(),
          plan
        })
        setUsageCount(0)
        return
      }

      const userData = userDoc.data() as UserUsage
      const lastReset = userData.lastReset.toDate()
      const now = new Date()
      
      if (lastReset.getMonth() !== now.getMonth() || lastReset.getFullYear() !== now.getFullYear()) {
        await setDoc(userRef, {
          comparisons: 0,
          lastReset: Timestamp.now(),
          plan
        })
        setUsageCount(0)
      } else {
        setUsageCount(userData.comparisons)
        setIsLimitReached(userData.comparisons >= monthlyLimit)
      }
    } catch (error) {
      console.error('Error checking usage:', error)
      setStatus('Unable to check usage. Some features may be limited while offline.')
      setUsageCount(0)
      setUserPlan('basic')
      setIsLimitReached(false)
    }
  }

  const updateUsageCount = async () => {
    const userRef = doc(db, 'usage', user.uid)
    await setDoc(userRef, {
      comparisons: increment(1),
      lastReset: Timestamp.now()
    }, { merge: true })
    
    const newCount = usageCount + 1
    setUsageCount(newCount)
    setIsLimitReached(newCount >= PLAN_LIMITS[userPlan])
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, setFile: (file: File | null) => void) => {
    const files = event.target.files
    if (files && files[0]) {
      setFile(files[0])
      setStatus('')
    }
  }

  const handleDrop = (event: React.DragEvent, setFile: (file: File | null) => void) => {
    event.preventDefault()
    const files = event.dataTransfer.files
    if (files && files[0]) {
      setFile(files[0])
      setStatus('')
    }
  }

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault()
  }

  const executeComparison = async (script: string, file1Content: ArrayBuffer, file2Content: ArrayBuffer) => {
    const CompareFunction = new Function('XLSX', 'file1', 'file2', 
      `return (async () => {
        ${script}
        return compareAndDisplayData(XLSX, file1, file2);
      })();`
    )
    return await CompareFunction(XLSX, file1Content, file2Content)
  }

  const handleCompare = async () => {
    if (isLimitReached) {
      setStatus(`Monthly comparison limit reached (${usageCount}/${PLAN_LIMITS[userPlan]}). Please try again next month.`)
      return
    }

    const validationErrors = []
    if (!file1) validationErrors.push("Please select the first file")
    if (!file2) validationErrors.push("Please select the second file")
    if (!script) validationErrors.push("Please select a comparison script")

    if (validationErrors.length > 0) {
      setStatus(validationErrors.join(", "))
      return
    }

    try {
      setStatus('Processing files...')
      
      const content1 = await readExcelFile(file1)
      const content2 = await readExcelFile(file2)

      setStatus('Running comparison...')
      const scriptContent = SCRIPTS[script as keyof typeof SCRIPTS]
      if (!scriptContent) {
        throw new Error('Invalid script selected')
      }
      
      const result = await executeComparison(scriptContent, content1, content2)
      
      await updateUsageCount()
      setResults(result)
      setStatus('Comparison complete!')
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'An error occurred')
    }
  }

  const readExcelFile = (file: File): Promise<ArrayBuffer> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (e) => resolve(e.target?.result as ArrayBuffer)
      reader.onerror = (e) => reject(new Error('Failed to read file'))
      reader.readAsArrayBuffer(file)
    })
  }

  const downloadResults = () => {
    if (results.length === 0) return
    
    const workbook = XLSX.utils.book_new()
    const worksheet = XLSX.utils.aoa_to_sheet(results)
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Results')
    XLSX.writeFile(workbook, 'Comparison_Results.xlsx')
  }

  const handleClear = () => {
    setFile1(null)
    setFile2(null)
    setScript('')
    setStatus('')
    setResults([])
    if (file1Ref.current) file1Ref.current.value = ''
    if (file2Ref.current) file2Ref.current.value = ''
  }

  const handleLogout = () => {
    signOut(auth)
  }

  const nextReset = new Date()
  nextReset.setMonth(nextReset.getMonth() + 1)
  nextReset.setDate(1)
  nextReset.setHours(0, 0, 0, 0)

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <img 
              src="https://github.com/davisricart/grbalance-auth/blob/main/public/images/gr-logo.png?raw=true" 
              alt="GR Logo" 
              className="h-12 w-auto object-contain" 
            />
            <div className="flex flex-col">
              <div className="text-sm font-medium text-gray-600">
                {userPlan === 'premium' ? 'Premium Plan' : 'Basic Plan'}
                <span className="text-gray-500"> ({usageCount}/{PLAN_LIMITS[userPlan]} uses)</span>
              </div>
              <div className="text-xs text-gray-500">
                Resets {nextReset.toLocaleDateString()}
              </div>
            </div>
          </div>
          
          <button
            onClick={handleLogout}
            className="text-gray-600 px-3 py-1.5 text-sm rounded-md border border-gray-200 hover:bg-gray-50 transition-colors duration-200"
          >
            Sign Out
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <label className="block text-sm font-medium text-gray-600">Upload First File</label>
              <div 
                className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors duration-200 ${
                  file1 ? 'border-emerald-400 bg-emerald-50/50' : 'border-gray-200 hover:border-gray-300'
                }`}
                onDrop={(e) => handleDrop(e, setFile1)}
                onDragOver={handleDragOver}
              >
                <input
                  type="file"
                  ref={file1Ref}
                  onChange={(e) => handleFileUpload(e, setFile1)}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
                <FileSpreadsheet className={`mx-auto h-12 w-12 ${file1 ? 'text-emerald-600' : 'text-gray-400'}`} />
                <p className="mt-2 text-sm text-gray-600 font-medium">
                  {file1 ? file1.name : "Drag & drop your first Excel or CSV file here"}
                </p>
                <button 
                  onClick={() => file1Ref.current?.click()}
                  className="mt-2 inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition-colors duration-200"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Select File
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <label className="block text-sm font-medium text-gray-600">Upload Second File</label>
              <div 
                className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors duration-200 ${
                  file2 ? 'border-emerald-400 bg-emerald-50/50' : 'border-gray-200 hover:border-gray-300'
                }`}
                onDrop={(e) => handleDrop(e, setFile2)}
                onDragOver={handleDragOver}
              >
                <input
                  type="file"
                  ref={file2Ref}
                  onChange={(e) => handleFileUpload(e, setFile2)}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
                <FileSpreadsheet className={`mx-auto h-12 w-12 ${file2 ? 'text-emerald-600' : 'text-gray-400'}`} />
                <p className="mt-2 text-sm text-gray-600 font-medium">
                  {file2 ? file2.name : "Drag & drop your second Excel or CSV file here"}
                </p>
                <button 
                  onClick={() => file2Ref.current?.click()}
                  className="mt-2 inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition-colors duration-200"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Select File
                </button>
              </div>
            </div>
          </div>

          <div className="mt-6 max-w-xs">
            <label className="block text-sm font-medium text-gray-600 mb-2">Select Comparison Script</label>
            <select 
              value={script}
              onChange={(e) => {
                setScript(e.target.value)
                setStatus('')
              }}
              className={`block w-full rounded-md shadow-sm transition-colors duration-200 ${
                script 
                  ? 'border-emerald-400 bg-emerald-50/50' 
                  : 'border-gray-200'
              } focus:border-emerald-500 focus:ring-emerald-500`}
            >
              <option value="">Select a script...</option>
              <option value="run5">Main HUB vs Sales</option>
              <option value="test20">Card Brand vs Name Comparison</option>
            </select>
          </div>

          {status && (
            <div className={`mt-4 p-3 rounded-md flex items-center gap-2 ${
              status.includes('error') || status.includes('limit reached')
                ? 'bg-red-50 text-red-700'
                : status.includes('complete')
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'bg-blue-50 text-blue-700'
            }`}>
              <AlertCircle className="h-5 w-5" />
              <span className="text-sm font-medium">{status}</span>
            </div>
          )}

          <div className="mt-6 flex gap-4">
            <button 
              onClick={handleCompare}
              disabled={isLimitReached}
              className={`inline-flex items-center px-6 py-2 rounded-md text-white transition-all duration-200 ${
                isLimitReached
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 hover:shadow-lg'
              }`}
            >
              Run Comparison
            </button>
            <button 
              onClick={handleClear}
              className="inline-flex items-center px-6 py-2 rounded-md text-white bg-gray-600 hover:bg-gray-700 transition-colors duration-200"
            >
              Clear Form
            </button>
          </div>

          {results.length > 0 && (
            <div className="mt-8 bg-white rounded-lg shadow-lg border border-gray-200">
              <div className="flex items-center justify-between p-6 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-700">Results</h2>
                <button
                  onClick={downloadResults}
                  className="inline-flex items-center px-4 py-2 text-sm rounded-md text-white bg-emerald-600 hover:bg-emerald-700 transition-colors duration-200"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      {results[0]?.map((header: string, i: number) => (
                        <th
                          key={i}
                          className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider"
                        >
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-100">
                    {results.slice(1).map((row, i) => (
                      <tr key={i}>
                        {row.map((cell: any, j: number) => {
                          const isNumber = typeof cell === 'number'
                          const isNegative = isNumber && cell < 0
                          
                          return (
                            <td
                              key={j}
                              className={`px-6 py-4 whitespace-nowrap ${
                                isNumber
                                  ? isNegative
                                    ? 'bg-red-50 text-red-600 font-medium'
                                    : 'bg-emerald-50 text-emerald-600 font-medium'
                                  : 'text-gray-900'
                              }`}
                            >
                              {cell}
                            </td>
                          )
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default App