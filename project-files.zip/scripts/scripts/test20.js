/**
 * Compare Card Brand and Name columns between two Excel files
 * @param {object} XLSX - XLSX library instance
 * @param {ArrayBuffer} file1 - First Excel file content
 * @param {ArrayBuffer} file2 - Second Excel file content
 * @returns {Array} Comparison results
 */
function compareAndDisplayData(XLSX, file1, file2) {
  // Read workbooks
  const workbook1 = XLSX.read(file1);
  const workbook2 = XLSX.read(file2);

  // Get first sheet from each workbook
  const sheet1 = workbook1.Sheets[workbook1.SheetNames[0]];
  const sheet2 = workbook2.Sheets[workbook2.SheetNames[0]];

  // Convert sheets to JSON
  const data1 = XLSX.utils.sheet_to_json(sheet1);
  const data2 = XLSX.utils.sheet_to_json(sheet2);

  // Extract values from the specified columns
  const cardBrands = new Set(data1.map(row => row['Card Brand']?.toString().toLowerCase().trim()));
  const names = new Set(data2.map(row => row['Name']?.toString().toLowerCase().trim()));

  // Find matching items
  const matches = new Set();
  cardBrands.forEach(brand => {
    if (names.has(brand)) {
      matches.add(brand);
    }
  });

  // Prepare results
  const results = [
    ['Metric', 'Count'],
    ['Total Card Brands in File 1', cardBrands.size],
    ['Total Names in File 2', names.size],
    ['Number of Matching Items', matches.size]
  ];

  // Add matching items list
  results.push(['', '']);
  results.push(['Matching Items:', '']);
  [...matches].sort().forEach(match => {
    results.push([match, '']);
  });

  return results;
}