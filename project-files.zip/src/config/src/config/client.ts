export interface ClientConfig {
  name: string;
  title: string;
  logo: string;
  theme: {
    primary: string;
    secondary: string;
  };
  firebase: {
    apiKey: string;
    authDomain: string;
    projectId: string;
    storageBucket: string;
    messagingSenderId: string;
    appId: string;
  };
}

const clientConfig: ClientConfig = {
  name: 'gr-balance',
  title: 'Beauty and Grace',
  logo: 'https://github.com/davisricart/grbalance-auth/blob/main/public/images/gr-logo.png?raw=true',
  theme: {
    primary: 'emerald',
    secondary: 'gray'
  },
  firebase: {
    apiKey: "AIzaSyBNdKlkXK2zLWKNbqL9HbnHgq3iHpg7AKs",
    authDomain: "gr-balance.firebaseapp.com",
    projectId: "gr-balance",
    storageBucket: "gr-balance.firebasestorage.app",
    messagingSenderId: "888884147701",
    appId: "1:888884147701:web:361c589f7c3488f4ba5cbc"
  }
};

export default clientConfig;